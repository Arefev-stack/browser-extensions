// background.js
importScripts('libs/ExtPay.js')

var extpay = ExtPay('spin-chrome-extension');
extpay.startBackground(); // required for ExtPay functionality

extpay.getUser().then(user => {
    console.log("ExtPay user:", user);
});

const ONBOARDING_COMPLETED_KEY = "onboardingCompleted";

const ENDPOINTS = {
    EXAMINE_URL: "https://www.vionika.com/services/examine/domain",
    BLOCK_PAGE: "https://www.spinbrowse.com/blocked/"
};

const DOMAINS = {
    SPIN_BROWSE: "spinbrowse.com",
    LOCALHOST: "localhost",
    CHROME: "chrome"
};

const DEFAULT_API_KEY = "oz2erssx768cHfzDMOO1PsyIz2EaJsyDppqrwmHckoHsrGBOJ2tPkA==";
// When no stored category settings exist, use these as the prohibited ones.
const PROHIBITED_CATEGORIES = [1011, 1062, 10002, 10007, 1031, 1058];

const CACHED_CATEGORIES_KEY = "cachedCategories";
const LAST_CLEAR_KEY = "lastCacheClearTimestamp";
const NEXT_RULE_ID_KEY = "nextRuleId";
const TAB_RULE_MAPPING_KEY = "tabRuleMapping";

const SEARCH_REGEX = {
    GOOGLE: /^(https?:\/\/)?(w{3}\.)?(images\.)?google\./i,
    BING: /^(https?:\/\/)?(w{3}\.)?([^?=]+\.)?bing\./i,
    YAHOO: /^(https?:\/\/)?(w{3}\.)?([^?=]+\.)?yahoo\./i,
    DUCKDUCKGO: /^(https?:\/\/)?(w{3}\.)?([^?=]+\.)?duckduckgo\./i,
    YOUTUBE: /^(https?:\/\/)?(w{3}\.)?([^?=]+\.)?youtube(\.com)?/i
};

let cachedCategoriesGlobal = null;

/**
 * Returns the selected categories from storage.
 * If the user is not paid or none are stored, returns the PROHIBITED_CATEGORIES fallback.
 */
async function getSelectedCategories() {
    const user = await extpay.getUser();
    if (!user || !user.paid) {
        return PROHIBITED_CATEGORIES;
    }
    const result = await chrome.storage.local.get({ categories: null });
    if (result.categories == null) {
        return PROHIBITED_CATEGORIES;
    } else {
        let selected = [];
        for (const key in result.categories) {
            if (result.categories[key]) {
                selected.push(Number(key));
            }
        }
        return selected;
    }
}

// Functions to interact with storage
async function getNextRuleId() {
    const result = await chrome.storage.local.get(NEXT_RULE_ID_KEY);
    let nextRuleId = result[NEXT_RULE_ID_KEY];
    if (!nextRuleId) {
        nextRuleId = 1000;
        await chrome.storage.local.set({ [NEXT_RULE_ID_KEY]: nextRuleId + 1 });
    } else {
        await chrome.storage.local.set({ [NEXT_RULE_ID_KEY]: nextRuleId + 1 });
    }
    return nextRuleId;
}

async function getTabRuleMapping() {
    const result = await chrome.storage.local.get(TAB_RULE_MAPPING_KEY);
    return result[TAB_RULE_MAPPING_KEY] || {};
}

async function setTabRuleMapping(mapping) {
    await chrome.storage.local.set({ [TAB_RULE_MAPPING_KEY]: mapping });
}

async function getCachedCategories() {
    if (!cachedCategoriesGlobal) {
        const result = await chrome.storage.local.get(CACHED_CATEGORIES_KEY);
        cachedCategoriesGlobal = result[CACHED_CATEGORIES_KEY] || {};
    }
    return cachedCategoriesGlobal;
}

async function saveDomainCategories(domain, categories) {
    cachedCategoriesGlobal[domain] = categories;
    await chrome.storage.local.set({ [CACHED_CATEGORIES_KEY]: cachedCategoriesGlobal });
}

async function checkAndClearCache() {
    try {
        const result = await chrome.storage.local.get(LAST_CLEAR_KEY);
        const lastClear = result[LAST_CLEAR_KEY];
        const now = Date.now();
        const oneDayInMs = 24 * 60 * 60 * 1000;

        if (!lastClear || (now - lastClear) > oneDayInMs) {
            const cacheResult = await chrome.storage.local.get(CACHED_CATEGORIES_KEY);
            const cachedCategories = cacheResult[CACHED_CATEGORIES_KEY] || {};

            const restrictedDomains = Object.keys(cachedCategories).filter(domain => {
                const categories = cachedCategories[domain];
                // Use our selected categories instead of PROHIBITED_CATEGORIES
                return categories.some(category => {
                    // For simplicity, if a category is in the prohibited list we consider it restricted.
                    return PROHIBITED_CATEGORIES.includes(category);
                });
            });

            if (restrictedDomains.length > 0) {
                const updatedCache = { ...cachedCategories };
                restrictedDomains.forEach(domain => {
                    delete updatedCache[domain];
                });
                cachedCategoriesGlobal = updatedCache;
                await chrome.storage.local.set({ [CACHED_CATEGORIES_KEY]: updatedCache });
                console.log(`Cleared cache for restricted domains: ${restrictedDomains.join(', ')}`);
            } else {
                console.log('No restricted domains found in cache to clear.');
            }

            await chrome.storage.local.set({ [LAST_CLEAR_KEY]: now });
        }
    } catch (error) {
        console.error('Error checking or clearing cached categories:', error);
    }
}

chrome.runtime.onInstalled.addListener(async (details) => {
    console.log("Extension installed or updated. Reason:", details.reason);

    const { [ONBOARDING_COMPLETED_KEY]: done } = await chrome.storage.local.get(ONBOARDING_COMPLETED_KEY);
    const user = await extpay.getUser();

    if (!done && !user.paid) {
        // If not done, open onboarding
        chrome.tabs.create({ url: "onboarding.html" });
    }

    const INITIAL_RULE_ID = 1000;
    try {
        const result = await chrome.storage.local.get(NEXT_RULE_ID_KEY);
        if (!result[NEXT_RULE_ID_KEY]) {
            await chrome.storage.local.set({ [NEXT_RULE_ID_KEY]: INITIAL_RULE_ID + 1 });
            console.log(`Initialized nextRuleId to ${INITIAL_RULE_ID + 1}`);
        }

        const currentRules = await new Promise((resolve, reject) => {
            chrome.declarativeNetRequest.getDynamicRules(resolve);
        });
        console.log("Current dynamic rules:", currentRules);

        const ruleIdsToRemove = currentRules.map(rule => rule.id);

        if (ruleIdsToRemove.length > 0) {
            await new Promise((resolve, reject) => {
                chrome.declarativeNetRequest.updateDynamicRules({
                    removeRuleIds: ruleIdsToRemove,
                    addRules: []
                }, () => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    } else {
                        resolve();
                    }
                });
            });
            console.log(`Removed existing dynamic rules: ${ruleIdsToRemove}`);
        }

        const initialRules = [{
            id: INITIAL_RULE_ID,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [
                    { header: "YouTube-Restrict", operation: "set", value: "Strict" }
                ]
            },
            condition: {
                urlFilter: "*://*.youtube.com/*",
                resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest"]
            }
        }];

        await new Promise((resolve, reject) => {
            chrome.declarativeNetRequest.updateDynamicRules({
                addRules: initialRules,
                removeRuleIds: []
            }, () => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve();
                }
            });
        });

        console.log("Added initial dynamic rules.");
        await checkAndClearCache();
    } catch (error) {
        console.error('Error during extension installation:', JSON.stringify(error));
    }
});

chrome.runtime.onStartup.addListener(async () => {
    console.log("Extension started up.");
    await checkAndClearCache();
});

chrome.tabs.onRemoved.addListener(async (tabId, removeInfo) => {
    console.log(`Tab removed: ${tabId}`);
    try {
        const mapping = await getTabRuleMapping();
        if (mapping[tabId]) {
            const ruleId = mapping[tabId];
            await new Promise((resolve, reject) => {
                chrome.declarativeNetRequest.updateDynamicRules({
                    removeRuleIds: [ruleId],
                    addRules: []
                }, () => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    } else {
                        resolve();
                    }
                });
            });
            console.log(`Removed dynamic rule with ID ${ruleId} for tab ${tabId}.`);
            delete mapping[tabId];
            await setTabRuleMapping(mapping);
        }
    } catch (error) {
        console.error(`Error removing dynamic rule for tab ${tabId}:`, error);
    }
});

chrome.webNavigation.onBeforeNavigate.addListener(async ({ frameId, url, tabId }) => {
    if (frameId !== 0 || !url || tabId < 0) return;

    try {
        await checkAndClearCache();
        const domainName = getDomainName(url);
        console.log(`Navigating to domain: ${domainName}`);

        const isAllowed = await isDomainAllowed(domainName);
        console.log(`Is domain allowed (${domainName}):`, isAllowed);
        if (!isAllowed || url.startsWith(DOMAINS.CHROME)) return;

        const { allowedDomains, blockedDomains, allowedOnlyDomains } = await getUserConfiguredDomains();
        console.log("User configured domains:", { allowedDomains, blockedDomains, allowedOnlyDomains });

        if (allowedOnlyDomains.length > 0) {
            if (!allowedOnlyDomains.includes(domainName)) {
                console.log(`Domain ${domainName} is not in the Allowed Only Domains list.`);
                await blockTab(tabId, url, domainName, "Allowed Only Domains");
                return;
            }
            console.log(`Domain ${domainName} is allowed exclusively.`);
            return;
        }

        if (blockedDomains.includes(domainName)) {
            console.log(`Domain ${domainName} is blocked by user configuration.`);
            await blockTab(tabId, url, domainName, "User configured");
            return;
        }

        if (allowedDomains.includes(domainName)) {
            console.log(`Domain ${domainName} is explicitly allowed by user configuration.`);
            return;
        }

        const safeSearchUrl = applySafeSearch(url);
        if (safeSearchUrl !== url) {
            console.log(`Applying Safe Search modification: ${safeSearchUrl}`);
            await updateTabUrl(tabId, safeSearchUrl);
            return;
        }

        const requestDomains = extractDomainsFromUrlParams(url, domainName);
        console.log(`Extracted request domains: ${requestDomains}`);
        // For each domain in the URL parameters, check its categories
        for (const requestDomain of requestDomains) {
            const categories = await fetchDomainCategories(requestDomain);
            console.log(`Categories for ${requestDomain}:`, categories);
            // Use selectedCategories from options (or fallback) for determining if the domain is restricted
            const selectedCategories = await getSelectedCategories();
            if (categories.some(category => selectedCategories.includes(category))) {
                const restrictedCategory = categories.find(category => selectedCategories.includes(category));
                console.log(`Domain ${requestDomain} is restricted with category ${restrictedCategory}`);
                await blockTab(tabId, url, requestDomain, restrictedCategory);
                break;
            }
        }
    } catch (error) {
        console.error('Error in onBeforeNavigate listener:', error);
    }
}, { urls: ["<all_urls>"], types: ['main_frame'] });

// Helper: Get domain name from URL
function getDomainName(urlString) {
    try {
        const { hostname } = new URL(urlString);
        return hostname.replace(/^www\./, '');
    } catch (error) {
        console.error(`Invalid URL: ${urlString}`, error);
        return '';
    }
}

// Function to check if a domain is allowed (basic check)
async function isDomainAllowed(domainName) {
    return domainName &&
        !domainName.includes(DOMAINS.SPIN_BROWSE) &&
        !domainName.startsWith(DOMAINS.LOCALHOST);
}

// Extract domains from URL parameters
function extractDomainsFromUrlParams(urlString, primaryDomain) {
    const url = new URL(urlString);
    const domains = [primaryDomain];

    url.searchParams.forEach(paramValue => {
        if (isValidURL(paramValue)) {
            domains.push(getDomainName(paramValue));
        }
    });

    return domains;
}

// Fetch domain categories from the external endpoint
async function fetchDomainCategories(domain) {
    const cached = await getCachedCategories();
    if (cached[domain]) {
        console.log(`Categories for ${domain} retrieved from cache:`, cached[domain]);
        return cached[domain];
    }

    try {
        console.log(`Fetching categories for domain: ${domain}`);
        const response = await fetch(ENDPOINTS.EXAMINE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ domainName: domain, key: DEFAULT_API_KEY, v: "1" })
        });

        if (!response.ok) {
            console.error(`Network response was not ok for domain ${domain}:`, response.statusText);
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        const { categories } = data;
        console.log(`Fetched categories for ${domain}:`, categories);
        await saveDomainCategories(domain, categories);
        return categories;
    } catch (error) {
        console.error(`Failed to fetch domain categories for ${domain}:`, error);
        return [];
    }
}

// Block a tab by updating dynamic rules
async function blockTab(tabId, originalUrl, domainName, category) {
    try {
        const blockUrl = `${ENDPOINTS.BLOCK_PAGE}?url=${encodeURIComponent(originalUrl)}&domain=${domainName}&category=${category}&managed=false&os=web`;
        const ruleId = await getNextRuleId();

        const newRule = {
            id: ruleId,
            priority: 1,
            action: { type: "redirect", redirect: { url: blockUrl } },
            condition: {
                urlFilter: `*://${domainName}/*`,
                resourceTypes: ["main_frame"]
            }
        };

        await new Promise((resolve, reject) => {
            chrome.declarativeNetRequest.updateDynamicRules({
                addRules: [newRule],
                removeRuleIds: []
            }, () => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve();
                }
            });
        });

        console.log(`Added dynamic rule ${ruleId} to block tab ${tabId} for domain ${domainName}.`);

        const mapping = await getTabRuleMapping();
        mapping[tabId] = ruleId;
        await setTabRuleMapping(mapping);

        await updateTabUrl(tabId, blockUrl);
    } catch (error) {
        console.error(`Failed to block tab ${tabId} for domain ${domainName}:`, error);
    }
}

// Apply Safe Search modifications to URLs
function applySafeSearch(url) {
    if (SEARCH_REGEX.GOOGLE.test(url) && !url.includes("safe=strict") && !isExcludedGoogleUrl(url)) {
        return appendQueryParam(url, "safe=strict");
    } else if (SEARCH_REGEX.BING.test(url) && !url.includes("adlt=strict") && !url.includes(".js")) {
        return appendQueryParam(url, "adlt=strict");
    } else if (SEARCH_REGEX.YAHOO.test(url) && !url.includes("vm=r")) {
        return appendQueryParam(url, "vm=r");
    } else if (SEARCH_REGEX.DUCKDUCKGO.test(url) && !url.includes("kp=1")) {
        return appendQueryParam(url, "kp=1");
    }
    return url;
}

// Check if URL is excluded (e.g. Google Maps)
function isExcludedGoogleUrl(url) {
    return ["/maps/", "/gmail", "/amp/", "/recaptcha/"].some(exclude => url.includes(exclude)) || url.endsWith("#");
}

// Append a query parameter to a URL
function appendQueryParam(url, param) {
    return url.includes("?") ? `${url}&${param}` : `${url}?${param}`;
}

// Validate a URL string
function isValidURL(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Update a tab's URL
async function updateTabUrl(tabId, url) {
    try {
        await chrome.tabs.update(tabId, { url });
    } catch (error) {
        console.error(`Failed to update tab ${tabId}:`, error);
    }
}

// Retrieve user-configured domains from storage
async function getUserConfiguredDomains() {
    const user = await extpay.getUser();
    if (user && user.paid) {
        const { allowedDomains, blockedDomains, allowedOnlyDomains } = await chrome.storage.local.get({
            allowedDomains: [],
            blockedDomains: [],
            allowedOnlyDomains: []
        });
        return { allowedDomains, blockedDomains, allowedOnlyDomains };
    } else {
        return { allowedDomains: [], blockedDomains: [], allowedOnlyDomains: [] };
    }
}

// Message listener for "checkDomainCategory" requests.
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Received message:", request);

    if (request.type === "checkDomainCategory") {
        const { domain } = request;
        if (!domain) {
            console.log("No domain provided in message.");
            sendResponse({ success: false, message: "No domain provided." });
            return true;
        }

        fetchDomainCategories(domain).then(async categories => {
            console.log(`Categories for ${domain}:`, categories);
            const selectedCategories = [1011, 1062];
            const isRestricted = categories.some(category => selectedCategories.includes(category));
            console.log(`Is domain restricted (${domain}):`, isRestricted);

            if (isRestricted) {
                sendResponse({ success: false, message: "Restricted: This domain belongs to a prohibited category." });
            } else {
                sendResponse({ success: true });
            }
        }).catch(error => {
            console.error(`Error checking domain category for ${domain}:`, error);
            sendResponse({ success: false, message: "Error checking domain category." });
        });

        return true; // asynchronous response
    }

    // New message listener: mark onboarding as completed.
    if (request.type === "onboardingCompleted") {
        chrome.storage.local.set({ [ONBOARDING_COMPLETED_KEY]: true }, () => {
            console.log("Onboarding marked as completed.");
            sendResponse({ success: true });
        });
        return true;
    }
});