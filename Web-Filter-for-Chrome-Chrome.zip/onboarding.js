// options.js
if (typeof ExtPay === 'function') {
    var extpay = ExtPay('spin-chrome-extension');
    extpay.startBackground(); // required for ExtPay functionality
} else {
    console.error("ExtPay is not available.");
}

// Onboarding step navigation
document.addEventListener("DOMContentLoaded", () => {
    const freePlan = document.getElementById('freePlan');
    const premiumPlan = document.getElementById('premiumPlan');

    function selectPlan(selectedPlan) {
        // Remove 'selected' class from both plans
        freePlan.classList.remove('selected');
        premiumPlan.classList.remove('selected');
        // Add 'selected' class to the clicked plan
        selectedPlan.classList.add('selected');
    }

    freePlan.addEventListener('click', function () {
        selectPlan(freePlan);
    });

    premiumPlan.addEventListener('click', function () {
        selectPlan(premiumPlan);
    });

    const getStartedBtn = document.getElementById("getStartedBtn");
    const planNextBtn = document.getElementById("planNextBtn");
    const startBrowsingBtn = document.getElementById("startBrowsingBtn");
    const goToSettingsBtn = document.getElementById("goToSettingsBtn");

    async function updateButtonVisibility() {
        const user = await extpay.getUser();
        if (!user.paid) {
            goToSettingsBtn.style.display = "none";
        }
    }

    updateButtonVisibility();

    function showStep(stepId) {
        const steps = document.querySelectorAll(".onboarding-step");
        steps.forEach(step => step.classList.remove("active"));
        const targetStep = document.getElementById(stepId);
        if (targetStep) {
            targetStep.classList.add("active");
        }
    }

    getStartedBtn.addEventListener("click", () => {
        showStep("step-2");
    });

    planNextBtn.addEventListener("click", () => {
        // If the Premium plan is selected, start the subscription flow.
        if (premiumPlan.classList.contains("selected")) {
            extpay.onPaid.addListener(user => {
                showStep("step-3");
            })
            extpay.openPaymentPage();
        } else {
            // Otherwise, proceed to the confirmation step.
            showStep("step-3");
        }
    });

    startBrowsingBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "onboardingCompleted" });
        chrome.tabs.create({ url: "chrome://newtab" });
        window.close();
    });

    goToSettingsBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "onboardingCompleted" });
        window.location.href = "options.html";
    });
});