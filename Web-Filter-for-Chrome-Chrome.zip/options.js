// options.js
if (typeof ExtPay === 'function') {
    var extpay = ExtPay('spin-chrome-extension');
    extpay.startBackground(); // required for ExtPay functionality
} else {
    console.error("ExtPay is not available.");
}

document.addEventListener("DOMContentLoaded", async () => {
    // Query DOM elements that won't change
    const sidebarNav = document.querySelector(".sidebar nav");
    let navButtons = document.querySelectorAll(".sidebar nav button");
    const sections = document.querySelectorAll(".section");
    const settingsContent = document.getElementById("main-content");
    const sidebar = document.getElementById("sidebar");

    // Subscription elements
    const subscriptionSection = document.getElementById("subscription-section");
    const subscriptionInfo = document.getElementById("subscription-info");
    const subscribeButton = document.getElementById("subscribe-button");

    // Domain management elements
    const allowedList = document.getElementById("allowed-list");
    const blockedList = document.getElementById("blocked-list");
    const allowedOnlyList = document.getElementById("allowed-only-list");
    const newAllowedDomainInput = document.getElementById("new-allowed-domain");
    const newBlockedDomainInput = document.getElementById("new-blocked-domain");
    const newAllowedOnlyDomainInput = document.getElementById("new-allowed-only-domain");
    const addAllowedButton = document.getElementById("add-allowed-domain");
    const addBlockedButton = document.getElementById("add-blocked-domain");
    const addAllowedOnlyButton = document.getElementById("add-allowed-only-domain");
    const allowedError = document.getElementById("allowed-error");
    const blockedError = document.getElementById("blocked-error");
    const allowedOnlyError = document.getElementById("allowed-only-error");

    // Passcode elements
    const passcodeOverlay = document.getElementById("passcode-overlay");
    const enterPasscodeInput = document.getElementById("enter-passcode");
    const submitPasscodeButton = document.getElementById("submit-passcode-button");
    const enterPasscodeError = document.getElementById("enter-passcode-error");
    const newPasscodeInput = document.getElementById("new-passcode");
    const confirmPasscodeInput = document.getElementById("confirm-passcode");
    const setPasscodeButton = document.getElementById("set-passcode-button");
    const removePasscodeButton = document.getElementById("remove-passcode-button");
    const passcodeError = document.getElementById("passcode-error");

    // Storage keys
    const allowedDomainsKey = "allowedDomains";
    const blockedDomainsKey = "blockedDomains";
    const allowedOnlyDomainsKey = "allowedOnlyDomains";
    const passcodeKey = "passcodeHash";
    const categoriesKey = "categories";

    // ---------- Subscription Handling ----------
    async function loadSubscriptionStatus() {
        try {
            const user = await extpay.getUser();
            console.log("ExtPay user:", user);
            const subscriptionNavButton = document.getElementById("subscription-nav");
            if (user.paid) {
                if (subscriptionNavButton) {
                    subscriptionNavButton.textContent = "Subscription";
                }
            } else {
                if (subscriptionNavButton) {
                    subscriptionNavButton.textContent = "Subscribe/Restore";
                }
            }
            // Clear any existing subscription info
            subscriptionInfo.innerHTML = "";

            const subscriptionHeader = document.getElementById("subscription-header");
            if (user.paid) {
                if (subscriptionHeader) {
                    subscriptionHeader.style.display = "none";
                }
                // Active subscription: show details and hide Subscribe button
                const startedDate = user.paidAt
                    ? new Date(user.paidAt).toLocaleDateString()
                    : "(unknown date)";
                subscriptionInfo.innerHTML = `
          <div class="subscription-status active">Subscription: Active</div>
          <div class="subscription-detail">Email: ${user.email || "N/A"}</div>
          <div class="subscription-detail">Started at: ${startedDate}</div>
        `;
                subscribeButton.textContent = "Subscription Options";
            } else {
                if (subscriptionHeader) {
                    subscriptionHeader.style.display = "block";
                }
                // Inactive subscription: render premium plan list (as on onboarding)
                subscriptionInfo.innerHTML = `
    <div>
      <h3 style="font-size: 1.5rem; margin: 0 0 10px; color: #ec1775;">Premium User</h3>
      <ul style="list-style: none; padding-left: 0; margin: 0;">
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Web Filtering</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Safe Search</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Filters Incognito Mode</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Allow unlimited domains</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Block unlimited domains</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Allow only specific domains</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Customize Content Categories</span>
        </li>
        <li style="justify-content: flex-start !important;">
          <span style="color: green;">✔</span>
          <span style="margin-left: 8px;">Passcode protect your settings</span>
        </li>
      </ul>
    </div>
  `;
                subscribeButton.textContent = "Subscribe/Restore";
            }
        } catch (err) {
            console.error("Error retrieving subscription status:", err);
            subscriptionInfo.innerHTML = `
        <div class="subscription-status inactive">Error loading subscription status.</div>
      `;
            subscribeButton.style.display = "inline-block";
        }
    }

    // Initially load subscription status
    await loadSubscriptionStatus();

    subscribeButton.addEventListener("click", async () => {
        extpay.onPaid.addListener(user => {
            window.location.reload();
        })

        extpay.openPaymentPage();
    });

    // ---------- Navigation Handling ----------
    // If subscription is not active, only allow the Subscription section.
    async function updateNavigation() {
        const user = await extpay.getUser();
        if (!user.paid) {
            // Disable all nav buttons except the subscription button
            navButtons.forEach(button => {
                if (button.id !== "subscription-nav") {
                    button.classList.add("disabled-nav");
                }
            });
            activateSection("subscription-section");
    } else {
        // Subscription is active: enable all nav buttons and select Categories section by default.
        navButtons.forEach(button => button.classList.remove('disabled-nav'));
        activateSection('categories-section');
    }
    }
    await updateNavigation();

    function activateSection(sectionId) {
        sections.forEach(section => section.classList.remove("active"));
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add("active");
        }
        navButtons.forEach(btn => btn.classList.remove("active"));
        const activeButton = document.querySelector(`.nav-button[data-target="${sectionId}"]`);
        if (activeButton) {
            activeButton.classList.add("active");
        }
    }

    // Sidebar navigation event listener: if subscription is inactive, force subscription section.
    const navContainer = document.querySelector(".sidebar nav");
    navContainer.addEventListener("click", async (event) => {
        const button = event.target.closest("button");
        if (!button) return;
        const targetSection = button.dataset.target;
        const user = await extpay.getUser();
        if (!user.paid) {
            // If subscription is inactive, always force Subscription section
            activateSection("subscription-section");
        } else {
            activateSection(targetSection);
            if (targetSection === "subscription-section") {
                loadSubscriptionStatus();
            }
        }
    });

    // ---------- Passcode Handling ----------
    const user = await extpay.getUser();
    if (user.paid) {  // Only for active subscription users
        const storedPasscodeVal = await chrome.storage.local.get(passcodeKey);
        if (storedPasscodeVal[passcodeKey]) {
            passcodeOverlay.style.display = "flex";
            sidebar.classList.add("hidden");
            settingsContent.classList.add("hidden");
        }
    }

    async function hashPasscode(passcode) {
        const encoder = new TextEncoder();
        const data = encoder.encode(passcode);
        const hashBuffer = await crypto.subtle.digest("SHA-256", data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
    }

    async function verifyPasscode(inputPasscode) {
        const storedHash = await chrome.storage.local.get(passcodeKey);
        if (!storedHash[passcodeKey]) return false;
        const inputHash = await hashPasscode(inputPasscode);
        return inputHash === storedHash[passcodeKey];
    }

    async function setNewPasscode(newPasscode) {
        const passcodeHash = await hashPasscode(newPasscode);
        await chrome.storage.local.set({ [passcodeKey]: passcodeHash });
    }

    async function removePasscode() {
        await chrome.storage.local.remove(passcodeKey);
    }

    function showPasscodeOverlay() {
        passcodeOverlay.style.display = "flex";
        sidebar.classList.add("hidden");
        settingsContent.classList.add("hidden");
    }

    function hidePasscodeOverlay() {
        passcodeOverlay.style.display = "none";
        sidebar.classList.remove("hidden");
        settingsContent.classList.remove("hidden");
    }

    submitPasscodeButton.addEventListener("click", async () => {
        const inputPasscode = enterPasscodeInput.value.trim();
        if (!inputPasscode) {
            enterPasscodeError.textContent = "Passcode cannot be empty.";
            return;
        }
        const isValid = await verifyPasscode(inputPasscode);
        if (isValid) {
            console.log("Passcode verified successfully.");
            enterPasscodeError.textContent = "";
            hidePasscodeOverlay();
            sessionStorage.setItem("authenticated", "true");
            activateSection("subscription-section");
        } else {
            console.log("Passcode verification failed.");
            enterPasscodeError.textContent = "Incorrect passcode.";
        }
    });

    setPasscodeButton.addEventListener("click", async () => {
        const newPasscode = newPasscodeInput.value.trim();
        const confirmPasscode = confirmPasscodeInput.value.trim();
        if (!newPasscode || !confirmPasscode) {
            passcodeError.textContent = "Both fields are required.";
            return;
        }
        if (newPasscode !== confirmPasscode) {
            passcodeError.textContent = "Passcodes do not match.";
            return;
        }
        await setNewPasscode(newPasscode);
        console.log("New passcode set successfully.");
        passcodeError.textContent = "";
        alert("Passcode has been set successfully.");
        newPasscodeInput.value = "";
        confirmPasscodeInput.value = "";
        sessionStorage.setItem("authenticated", "true");
        activateSection("subscription-section");
    });

    removePasscodeButton.addEventListener("click", async () => {
        const confirmation = confirm("Are you sure you want to remove the passcode?");
        if (confirmation) {
            await removePasscode();
            console.log("Passcode removed successfully.");
            passcodeError.textContent = "";
            alert("Passcode has been removed.");
            sessionStorage.removeItem("authenticated");
            activateSection("subscription-section");
        }
    });

    // ---------- Categories Section ----------
    const categoriesList = [
        { id: 10002, title: "Prone to Bad Content", description: "Sites that occasionally display explicit content.", default: true },
        { id: 1011, title: "Pornography", description: "Content containing explicit sexual material.", default: true },
        { id: 1062, title: "Nudity", description: "Sites showing nudity.", default: true },
        { id: 10007, title: "Unsafe Search Engines", description: "Search engines that do not filter explicit content.", default: true },
        { id: 1031, title: "File Sharing Sites", description: "Sites for sharing files.", default: true },
        { id: 1027, title: "Gambling", description: "Online gambling and betting sites.", default: false },
        { id: 1010, title: "Drugs", description: "Sites related to drugs and narcotics.", default: false },
        { id: 1076, title: "Alcohol & Tobacco", description: "Sites related to alcohol or tobacco.", default: false },
        { id: 1008, title: "Cult & Occult", description: "Sites with occult or cult content.", default: false },
        { id: 1014, title: "Social Networking", description: "Social networking sites.", default: false },
        { id: 1018, title: "Dating", description: "Online dating sites.", default: false },
        { id: 1019, title: "Sex Education", description: "Educational content about sexual health.", default: false },
        { id: 1020, title: "Religion", description: "Sites related to religious content.", default: false },
        { id: 1021, title: "Entertainment & Arts", description: "Art, music, and entertainment sites.", default: false },
        { id: 1022, title: "Personal Sites & Blogs", description: "Personal websites and blogs.", default: false },
        { id: 1025, title: "Streaming Media", description: "Sites for streaming video or audio.", default: false },
        { id: 1026, title: "Job Search", description: "Job search and career sites.", default: false },
        { id: 1030, title: "Shareware & Freeware", description: "Software download sites.", default: false },
        { id: 1033, title: "Hacking", description: "Sites related to hacking.", default: false },
        { id: 1034, title: "Games", description: "Gaming websites.", default: false },
        { id: 1036, title: "Weapons", description: "Sites related to weapons.", default: false },
        { id: 1037, title: "Pay to Surf", description: "Sites that pay you to surf the web.", default: false },
        { id: 1038, title: "Hunting & Fishing", description: "Sites related to hunting and fishing.", default: false },
        { id: 1044, title: "Questionable", description: "Sites with questionable content.", default: false },
        { id: 1046, title: "Hate & Racism", description: "Sites that promote hate or racism.", default: false },
        { id: 1047, title: "Personal Storage", description: "Personal file storage sites.", default: false },
        { id: 1048, title: "Violence & Suicide", description: "Content with violent or self-harm imagery.", default: false },
        { id: 1049, title: "Keyloggers & Monitoring", description: "Sites related to keyloggers or surveillance.", default: false },
        { id: 1050, title: "Search Engines", description: "Various search engines.", default: false },
        { id: 1052, title: "Web Ads", description: "Online advertisement sites.", default: false },
        { id: 1053, title: "Plagiarism", description: "Sites related to plagiarism.", default: false },
        { id: 1054, title: "Gross", description: "Sites with gross content.", default: false },
        { id: 1056, title: "Malware Sites", description: "Sites that host malware.", default: false },
        { id: 1057, title: "Phishing & Other Frauds", description: "Sites involved in phishing or scams.", default: false },
        { id: 1058, title: "VPN or Proxy Sites", description: "Sites offering VPN or proxy services.", default: false },
        { id: 1059, title: "Spyware & Adware", description: "Sites that distribute spyware or adware.", default: false },
        { id: 1064, title: "Illegal", description: "Sites with illegal content.", default: false },
        { id: 1066, title: "Internet Communications", description: "Sites for internet communications.", default: false },
        { id: 1067, title: "Bot Nets", description: "Sites related to bot nets.", default: false },
        { id: 1068, title: "Abortion", description: "Content related to abortion.", default: false },
        { id: 1069, title: "Health & Medicine", description: "Health and medicine information.", default: false },
        { id: 1071, title: "Spam URLs", description: "Sites flagged as spam.", default: false },
        { id: 1075, title: "Parked Domains", description: "Parked or inactive domains.", default: false },
        { id: 1078, title: "Image & Video Search", description: "Image and video search description.", default: false },
        { id: 1079, title: "Fashion & Beauty", description: "Fashion and beauty related sites.", default: false },
        { id: 2002, title: "Web Hosting Sites", description: "Web hosting provider sites.", default: false }
    ];

    let storedCategories = {};
    chrome.storage.local.get([categoriesKey], (result) => {
        storedCategories = result[categoriesKey] || {};
        // If not set, initialize with defaults
        categoriesList.forEach(cat => {
            if (!(cat.id in storedCategories)) {
                storedCategories[cat.id] = cat.default;
            }
        });
        chrome.storage.local.set({ [categoriesKey]: storedCategories });
        renderCategories();
    });

    function renderCategories() {
        const catListEl = document.getElementById("category-list");
        catListEl.innerHTML = "";
        // Sort so that default-enabled come first
        const sortedCategories = [...categoriesList].sort((a, b) => {
            if (a.default === b.default) return a.id - b.id;
            return a.default ? -1 : 1;
        });
        sortedCategories.forEach(cat => {
            const li = document.createElement("li");
            const label = document.createElement("label");
            label.className = "toggle-control";
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.id = `category-${cat.id}`;
            checkbox.checked = storedCategories[cat.id];
            // If the category is default-enabled, disable the checkbox so it can't be unchecked
            if (cat.default) {
                checkbox.disabled = true;
            }
            label.appendChild(checkbox);
            const toggleSpan = document.createElement("span");
            toggleSpan.className = "toggle-switch";
            label.appendChild(toggleSpan);

            const textContainer = document.createElement("div");
            textContainer.className = "category-details";
            const titleEl = document.createElement("div");
            titleEl.textContent = cat.title;
            titleEl.style.fontWeight = "600";
            const descEl = document.createElement("div");
            descEl.textContent = cat.description;
            descEl.style.color = "#777";

            textContainer.appendChild(titleEl);
            textContainer.appendChild(descEl);
            label.appendChild(textContainer);

            li.appendChild(label);
            catListEl.appendChild(li);

            checkbox.addEventListener("change", (e) => {
                // Only update if not a default category (should be disabled anyway)
                if (!cat.default) {
                    storedCategories[cat.id] = e.target.checked;
                    chrome.storage.local.set({ [categoriesKey]: storedCategories });
                    chrome.runtime.sendMessage({
                        action: "categoryToggle",
                        categoryId: cat.id,
                        enabled: e.target.checked
                    });
                }
            });
        });
    }

    // ---------- Domain Management ----------
    const domainData = await chrome.storage.local.get([allowedDomainsKey, blockedDomainsKey, allowedOnlyDomainsKey]);
    const allowedDomains = domainData[allowedDomainsKey] || [];
    const blockedDomains = domainData[blockedDomainsKey] || [];
    const allowedOnlyDomains = domainData[allowedOnlyDomainsKey] || [];

    function renderList(listElement, domains, removeHandler) {
        listElement.innerHTML = "";
        domains.forEach(domain => {
            const li = document.createElement("li");
            li.textContent = domain;
            const removeButton = document.createElement("button");
            removeButton.textContent = "Remove";
            removeButton.addEventListener("click", () => {
                removeHandler(domain);
                renderList(listElement, domains, removeHandler);
            });
            li.appendChild(removeButton);
            listElement.appendChild(li);
        });
    }

    async function saveDomains() {
        await chrome.storage.local.set({
            [allowedDomainsKey]: allowedDomains,
            [blockedDomainsKey]: blockedDomains,
            [allowedOnlyDomainsKey]: allowedOnlyDomains
        });
        console.log("Saved domains to storage:", { allowedDomains, blockedDomains, allowedOnlyDomains });
    }

    function validateDomain(domain) {
        const domainRegex = /^(?!:\/\/)([a-zA-Z0-9_-]+\.)+[a-zA-Z]{2,6}$/;
        return domainRegex.test(domain);
    }

    async function addDomain(domain, list, errorElement, otherLists = [], loadingElement) {
        errorElement.textContent = "";
        if (!domain) {
            errorElement.textContent = "Domain cannot be empty.";
            return false;
        }
        if (!validateDomain(domain)) {
            errorElement.textContent = "Invalid domain format.";
            return false;
        }
        if (list.includes(domain)) {
            errorElement.textContent = "This domain is already added.";
            return false;
        }
        for (let otherList of otherLists) {
            if (otherList.includes(domain)) {
                errorElement.textContent = "This domain is already in another list.";
                return false;
            }
        }
        if (loadingElement) loadingElement.style.display = "inline";
        console.log(`Sending message to background.js to check category for domain: ${domain}`);
        try {
            const response = await chrome.runtime.sendMessage({
                type: "checkDomainCategory",
                domain: domain
            });
            console.log("Received response from background.js:", response);
            if (loadingElement) loadingElement.style.display = "none";
            if (!response || !response.success) {
                errorElement.textContent = response
                    ? (response.message || "Failed to check domain category.")
                    : "No response from background script.";
                return false;
            }
            list.push(domain);
            await saveDomains();
            console.log(`Domain ${domain} added to list.`);
            return true;
        } catch (error) {
            console.error(`Error adding domain ${domain}:`, error);
            errorElement.textContent = error.message || "An error occurred while adding the domain.";
            if (loadingElement) loadingElement.style.display = "none";
            return false;
        }
    }

    function removeDomainFromList(domain, list) {
        const index = list.indexOf(domain);
        if (index !== -1) {
            list.splice(index, 1);
            saveDomains();
            console.log(`Domain ${domain} removed from list.`);
        }
    }

    addAllowedButton.addEventListener("click", async () => {
        const domain = newAllowedDomainInput.value.trim();
        const loadingElement = document.getElementById("allowed-loading");
        const success = await addDomain(
            domain,
            allowedDomains,
            allowedError,
            [blockedDomains, allowedOnlyDomains],
            loadingElement
        );
        if (success) {
            newAllowedDomainInput.value = "";
            renderList(allowedList, allowedDomains, d => removeDomainFromList(d, allowedDomains));
        }
    });

    addAllowedOnlyButton.addEventListener("click", async () => {
        const domain = newAllowedOnlyDomainInput.value.trim();
        const loadingElement = document.getElementById("allowed-only-loading");
        const success = await addDomain(
            domain,
            allowedOnlyDomains,
            allowedOnlyError,
            [allowedDomains, blockedDomains],
            loadingElement
        );
        if (success) {
            newAllowedOnlyDomainInput.value = "";
            renderList(allowedOnlyList, allowedOnlyDomains, d => removeDomainFromList(d, allowedOnlyDomains));
        }
    });

    addBlockedButton.addEventListener("click", async () => {
        const domain = newBlockedDomainInput.value.trim();
        const success = await addDomain(
            domain,
            blockedDomains,
            blockedError,
            [allowedDomains, allowedOnlyDomains],
            null
        );
        if (success) {
            newBlockedDomainInput.value = "";
            renderList(blockedList, blockedDomains, d => removeDomainFromList(d, blockedDomains));
        }
    });

    // Allow Enter key to add domain
    newAllowedDomainInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            addAllowedButton.click();
        }
    });
    newAllowedOnlyDomainInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            addAllowedOnlyButton.click();
        }
    });
    newBlockedDomainInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            addBlockedButton.click();
        }
    });

    // Render initial domain lists
    renderList(allowedList, allowedDomains, d => removeDomainFromList(d, allowedDomains));
    renderList(blockedList, blockedDomains, d => removeDomainFromList(d, blockedDomains));
    renderList(allowedOnlyList, allowedOnlyDomains, d => removeDomainFromList(d, allowedOnlyDomains));
});